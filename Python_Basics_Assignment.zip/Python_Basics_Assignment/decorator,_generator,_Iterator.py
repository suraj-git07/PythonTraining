#Demonstration of  decorator, generator, and iterator

# DECORATOR - Prints function name before calling it
def print_name(func):
    """Simple decorator that prints function name."""
    def wrapper():
        print(f"Calling function: {func.__name__}")
        return func()
    return wrapper


# Using decorator
@print_name
def say_hello():
    """Simple hello function."""
    return "Hello World!"


@print_name
def get_number():
    """Returns a number."""
    return 42


# GENERATOR - Simple number generator
def count_up_to(max_num):
    """Generate numbers from 1 to max_num."""
    num = 1
    while num <= max_num:
        yield num
        num += 1


def get_fruits():
    """Generate fruit names."""
    fruits = ["apple", "banana", "orange"]
    for fruit in fruits:
        yield fruit


# ITERATOR - Simple counter
class SimpleCounter:
    """Count from 1 to a maximum number."""
    
    def __init__(self, max_count):
        self.max_count = max_count
        self.current = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.current >= self.max_count:
            raise StopIteration
        self.current += 1
        return self.current


# USING DECORATOR
print("DECORATOR ")
message = say_hello()
print(message)

number = get_number()
print(f"Got number: {number}")

# USING GENERATOR
print("\nGENERATOR")
print("Counting up to 5:")
for num in count_up_to(5):
    print(num, end=" ")

print("\nFruits:")
for fruit in get_fruits():
    print(fruit)

# USING ITERATOR
print("\nITERATOR")
print("Simple counter up to 4:")
counter = SimpleCounter(4)
for count in counter:
    print(count, end=" ")

print("\nUsing next() manually:")
counter2 = SimpleCounter(3)
print(next(counter2))  
print(next(counter2))  
print(next(counter2))  