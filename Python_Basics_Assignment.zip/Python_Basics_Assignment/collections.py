# Python Collections Examples.

def demonstrate_lists():
    """Demonstrate list operations"""
    print("\nLISTS")
   
    # Creating lists
    fruits = ['apple', 'banana', 'orange', 'apple']
    numbers = [1, 2, 3, 4, 5]
    mixed_list = ['hello', 42, 3.14, True]
    
    print(f"Fruits list: {fruits}")
    print(f"Numbers list: {numbers}")
    print(f"Mixed list: {mixed_list}")
    
    # List operations
    fruits.append('grape')
    print(f"After append: {fruits}")
    
    fruits.insert(1, 'mango')
    print(f"After insert at index 1: {fruits}")
    
    fruits.remove('apple')
    print(f"After removing 'apple': {fruits}")
    
    popped = fruits.pop()
    print(f"Popped element: {popped}")
    print(f"List after pop: {fruits}")
    
    # Slicing
    print(f"First 3 fruits: {fruits[:3]}")
    print(f"Last 2 fruits: {fruits[-2:]}")


def demonstrate_tuples():
    """Demonstrate tuple operations"""
    print("\nTUPLES")
    
    # Creating tuples
    coordinates = (10, 20)
    colors = ('red', 'green', 'blue', 'red')
    single_tuple = (42,)
    empty_tuple = ()
    
    print(f"Coordinates: {coordinates}")
    print(f"Colors: {colors}")
    print(f"Single element tuple: {single_tuple}")
    print(f"Empty tuple: {empty_tuple}")
    
    # Tuple operations
    print(f"First coordinate: {coordinates[0]}")
    print(f"Second coordinate: {coordinates[1]}")
    
    # Tuple unpacking
    x, y = coordinates
    print(f"Unpacked - x: {x}, y: {y}")
    
    # Tuple methods
    print(f"Count of 'red' in colors: {colors.count('red')}")
    print(f"Index of 'blue': {colors.index('blue')}")


def demonstrate_sets():
    """Demonstrate set operations and usage."""
    print("\nSETS")
    
    # Creating sets
    unique_numbers = {1, 2, 3, 4, 5}
    fruits_set = {'apple', 'banana', 'orange', 'apple'}
    empty_set = set() 
    
    print(f"Unique numbers: {unique_numbers}")
    print(f"Fruits set (duplicates removed): {fruits_set}")
    print(f"Empty set: {empty_set}")
    
    # Set operations
    fruits_set.add('grape')
    print(f"After adding grape: {fruits_set}")
    
    fruits_set.discard('banana')
    print(f"After discarding banana: {fruits_set}")
    
    # Set operations with other sets
    set1 = {1, 2, 3, 4}
    set2 = {3, 4, 5, 6}
    
    print(f"Set 1: {set1}")
    print(f"Set 2: {set2}")
    print(f"Union (|): {set1 | set2}")
    print(f"Intersection (&): {set1 & set2}")
    print(f"Difference (-): {set1 - set2}")


def demonstrate_dictionaries():
    """Demonstrate dictionary operations and usage."""
    print("\nDICTIONARIES")
    
    # Creating dictionaries
    student = {
        'name': 'Alice',
        'age': 20,
        'grade': 'A',
        'subjects': ['Math', 'Physics', 'Chemistry']
    }
    
    empty_dict = {}
    
    print(f"Student dict: {student}")
    
    # Dictionary operations
    print(f"Student name: {student['name']}")
    print(f"Student age: {student.get('age', 'default')}")
    
    # Adding/updating
    student['email'] = 'alice@email.com'
    student['age'] = 21
    print(f"After updates: {student}")
    
    # Dictionary methods
    print(f"Keys: {list(student.keys())}")
    print(f"Values: {list(student.values())}")
    print(f"Items: {list(student.items())}")


def main():
    print("PYTHON COLLECTIONS")
    
    demonstrate_lists()
    demonstrate_tuples()
    demonstrate_sets()
    demonstrate_dictionaries()

if __name__ == "__main__":
    main() #here it means that this main func only run whern I execute this file