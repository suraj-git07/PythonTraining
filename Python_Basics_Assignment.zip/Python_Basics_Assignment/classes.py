# class implementation with inheritanc

class Person:
    """class representing a person."""
    
    def __init__(self, name, age, email):
        self.name = name
        self.age = age
        self.email = email
    
    def display_info(self):
        """Display person info."""
        print(f"Name: {self.name}, Age: {self.age}, Email: {self.email}")
    
    def update_age(self, new_age):
        """Update person's age."""
        self.age = new_age


class Student(Person):
    """Student class inheriting from Person."""
    
    def __init__(self, name, age, email, student_id, grade):
        super().__init__(name, age, email) #super func is used to call the func of parent class
        self.student_id = student_id
        self.grade = grade
    
    def display_info(self):
        """Display student info"""
        super().display_info()
        print(f"Student ID: {self.student_id}, Grade: {self.grade}")
    
    def update_grade(self, new_grade):
        """Update student's grade."""
        self.grade = new_grade


# Using the classes
person1 = Person("Suraj Mishra", 22, "surajmishra@email.com")
student1 = Student("Aditya Raj", 23, "adity@email.com", "S1", "A+")

print("Person Information:")
person1.display_info()

print("\nStudent Information:")
student1.display_info()

print("\nAfter updates:")
person1.update_age(31)
student1.update_grade("O")

person1.display_info()
print()
student1.display_info()